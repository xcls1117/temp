# 

## classes
['object', 'normal', 'lose', 'damage', 'rust', 'incorrect', 'open']
