#!usr/bin/python
# -*- coding:utf-8 -*-


# 通过解析xml文件
'''
try:
    import xml.etree.CElementTree as ET
except:
    import xml.etree.ElementTree as ET

从Python3.3开始ElementTree模块会自动寻找可用的C库来加快速度
'''
import xml.etree.ElementTree as ET
import os
import sys
import cv2
from tqdm import tqdm
import numpy as np
import json
import random

train_json='train.json'
val_json='val.json'

LABLES = ['object', 'normal', 'lose', 'damage', 'rust', 'incorrect', 'open']

#label验证函数
def validate_label(xmin, ymin, xmax, ymax, width, height):
   
    """Validate labels."""
    # assert 0 <= xmin < width, "xmin must in [0, {}), given {}".format(width, xmin)
    # assert 0 <= ymin < height, "ymin must in [0, {}), given {}".format(height, ymin)
    # assert xmin < xmax <= width, "xmax must in (xmin, {}], given {}".format(width, xmax)
    # assert ymin < ymax <= height, "ymax must in (ymin, {}], given {}".format(height, ymax)
    if xmin < 0:
        xmin = 0
    if ymin < 0:
        ymin = 0
    if xmax > width:
        xmax = width
    if ymax > height:
        ymax = height
    
    return xmin, ymin, xmax, ymax

def get_all_data(xmls_set,xmls_path,image_src_path):
    ret = []
    for xmlFilePath in tqdm(xmls_set):
        if not xmlFilePath.endswith('.xml'):
            continue
        try:
            tree = ET.parse(os.path.join(xmls_path,xmlFilePath))
            # 获得根节点
            root = tree.getroot()
        except Exception as e:  # 捕获除与程序退出sys.exit()相关之外的所有异常
            print("parse test.xml fail!")
            sys.exit()
        
        one_data = {}
        image_path = os.path.join(image_src_path, xmlFilePath[:-4]+'.jpg')
        one_data['image_path'] = image_path
        one_data['attr'] = [0,0,0,0,0,0,0]
        one_data['box'] = [0,0,0,0]

        objects = root.findall("object")

        for obj in objects:
            xml_box = obj.find('bndbox')
            xmin = (int(xml_box.find('xmin').text))
            ymin = (int(xml_box.find('ymin').text))
            xmax = (int(xml_box.find('xmax').text))
            ymax = (int(xml_box.find('ymax').text))
            one_data['box'] = [xmin, ymin, xmax,ymax]

            cls_names = obj.findall('class')
            for cls_name in cls_names:
                cls_name = cls_name.text.lower().strip()
                one_data['attr'][LABLES.index(cls_name)] = 1

        ret.append(one_data)
    return ret

if __name__ == "__main__":
    image_src_path = sys.argv[1]
    xmls_path = sys.argv[2]

    allxmls = os.listdir(xmls_path)

    all_data = get_all_data(allxmls, xmls_path, image_src_path)

    random.shuffle(all_data)
    ratio = 0.95
    train_json_list = all_data[:int(ratio*len(all_data))]
    val_json_list = all_data[int(ratio*len(all_data)):]

    with open(train_json,'w') as f:
        json.dump(train_json_list, f,indent=2)
    
    with open(val_json,'w') as f:
        json.dump(val_json_list, f,indent=2)
