

import os
import numpy as np
from easydict import EasyDict as edict

config = edict()
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

config.TRAIN = edict()
#### below are params for dataiter
config.TRAIN.process_num = 8 
config.TRAIN.prefetch_size = 30
############

config.TRAIN.num_gpu = 1
config.TRAIN.batch_size = 2 
config.TRAIN.log_interval = 10                  ##10 iters for a log msg
config.TRAIN.epoch = 150

config.TRAIN.lr_value_every_epoch = [0.00001,0.0001,0.001,0.0001,0.00001,0.000001,0.0000001]          ####lr policy
config.TRAIN.lr_decay_every_epoch = [1,2,50,70,90,100]
config.TRAIN.weight_decay_factor = 5.e-4                                    ####l2
config.TRAIN.vis=False                                                      #### if to check the training data
config.TRAIN.mix_precision=False                                            ##use mix precision to speedup, tf1.14 at least
config.TRAIN.opt='Adam'                                                     ##Adam or SGD

### add by jason li
config.TRAIN.lr = 0.01
config.TRAIN.lr_steps = [50,100,150]
config.TRAIN.lr_steps_gamma = 0.3


config.MODEL = edict()
config.MODEL.model_path = './models' #'/project/train/models/final/attr_'                                        ## save directory
config.MODEL.hin = 224                                                      # input size during training , 128,160,   depends on
config.MODEL.win = 224
config.MODEL.channel = 3
config.MODEL.Activation = 'relu' # 'relu6'
config.MODEL.with_preprocess = True #False
config.MODEL.out_channel=7

config.MODEL.net_structure='MobileNetv2' # 'ghost_net'  # 'MobileNetv2'
config.MODEL.net_size = '0.25'
config.MODEL.pretrained_model=None

config.DATA = edict()

config.DATA.root_path=''
config.DATA.train_txt_path='./train.json'
config.DATA.val_txt_path='./val.json'

config.DATA.PIXEL_MEAN = [127.5, 127.5, 127.5]             ###rgb
config.DATA.PIXEL_STD = [128., 128., 128.]              

config.DATA.base_extend_range=[0.1,0.2]                 ###extand
config.DATA.scale_factor=[0.7,1.35]                     ###scales

config.MODEL.pruning=False               ## pruning flag  add l1 reg to bn/beta, no use for tmp
config.MODEL.pruning_bn_reg=0.00005
